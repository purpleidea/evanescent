#!/usr/local/bin/perl

use strict;
use CGI ':standard';

my $name=param('Name');
my $qts=param('Qts');
my $price=param('Price');
my $delete=param('Delete');







sub List
{
open (MYFILE, 'Stock.txt');
my $file=MYFILE;

print "Content-type:text/html\n\n";

print "<html>\n";
print "<head>\n";
print "<title>CGI Test</title>\n";
print "</head>\n";
print "<body>\n";
print "<h1>\n";
print $file;
print "</h1>\n";
print "</body></html>\n";

close(MYFILE);
}


sub Add
{
local($name)=@_;
open (MYFILE, '>>Stock.txt');
print MYFILE "$name $qts $price\n"; 
close(MYFILE);
}

sub delete
{
open (MYFILE, '>>Stock.txt');
$list=MYFILE;
$list =~ s/$name/ /

}



#main program

if($name!=' '){
Add($name);
}
if($delete!=' '){
delete;
}
List;
