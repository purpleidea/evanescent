#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(){

  const char *data = getenv("QUERY_STRING");
  int game;
  int quantity;
  int quantity1;
  int quantity2;
  int quantity3;
  float total = 0.00;
  float price;
  char read[100];
  int empty1 = 0;
  int empty2 = 0;
  int empty3 = 0;
  FILE *file = fopen("inventory.csv", "r");
  
  fgets(read, 100, file);
  sscanf(read, "%*s %d %*f",&quantity1);

  fgets(read, 100, file);
  sscanf(read, "%*s %d", &quantity2);

  fgets(read, 100, file);
  sscanf(read, "%*s %d", &quantity3);

  fclose(file);

  printf("Content-Type: text/html; charset=us-ascii\n\n");
  printf("<html><body bgcolor=\"black\" text=\"green\">");
  printf("<br><br>		Antlion Gaming Billing<br>		--------------------<br>");

  char *ptr = strstr(data, "product=01");
  game = 1;
  if (ptr != NULL){
    if(sscanf(ptr, "product=01&quantity=%d", &quantity) != EOF){
      if (quantity <= quantity1){ 
        price = quantity * 19.99;
        total += price;
        printf("		Conan: %d x 19.99$     %.2f $<br>", quantity, price);
        quantity1 -= quantity;
      }
      else{
        empty1 = 1;
      }
    }
  }

  char *ptr2 = strstr(data, "product=02");
  game = 2;
  if(ptr2 != NULL){
    if(sscanf(ptr2, "product=02&quantity=%d", &quantity) != EOF){
      if (quantity <= quantity2){
        price = quantity * 9.99;
        total += price;
        printf("		Sea Tycoon: %d x 9.99 $     %.2f $<br>", quantity, price);
        quantity2 -= quantity;
      }
      else{
        empty2 = 1;
      }
    }
  }

  char *ptr3 = strstr(data, "product=03");
  game = 3;
  if(ptr3 != NULL){
    if (sscanf(ptr3, "product=03&quantity=%d", &quantity) != EOF){
      if (quantity <= quantity3){
        price = quantity * 14.99;
        total += price;
        printf("		Space Racing: %d x 14.99 $     %.2f $<br>", quantity, price);
        quantity3 -= quantity;
      }
      else{
        empty3 = 1;
      } 
    }
  }

  printf("		---<br>		Total: %.2f $<br>", total);

  float gst = total * 0.05;
  total += gst;

  printf("		GST(5 percent): %.2f $<br>", gst);
  printf("		Subtotal: %.2f $<br>", total);

  float pst = total * 0.075;
  total += pst;

  printf("		PST(7.5 percent): %.2f $<br>", pst);

  printf("		--------------------<br>		Grand Total: %.2f $<br><br>", total);

  if (empty1 == 1 || empty2 == 1 || empty3 == 1){
    printf("	We're sorry. Some of the items you asked for cannot be supplied to you in the desired quantity:<br><br>");
    
    if (empty1 == 1){
      printf("		- Not enough copies of Conan. We currently have %d copies<br>", quantity1);
    }
    if (empty2 == 1){
      printf("		- Not enough copies of Sea Tycoon. We currently have %d copies<br>", quantity2);
    }
    if (empty3 == 1){
      printf("		- Not enough copies of Space Racing. We currently have %d copies<br>", quantity3);
    }

    printf("<br>	Again, please forgive the lack of available copies.<br>	We invite you to return to the catalogue page and to modify your request.<br><br>");
  }

  FILE *file2 = fopen("inventory.csv", "w");

  fprintf(file2, "conan %d 19.99\nseatycoon %d 9.99\nspaceracing %d 14.99\n", quantity1, quantity2, quantity3);

  fclose(file2);

  printf("	Click <a href=\"http://www.cs.mcgill.ca/~jpitre5/catalogue.html\">here</a> to return to the catalogue page or <a href=\"http://www.cs.mcgill.ca/~jpitre5/home.html\">here</a> to return to the home page.<br></body></html>");

  return (1);
}
