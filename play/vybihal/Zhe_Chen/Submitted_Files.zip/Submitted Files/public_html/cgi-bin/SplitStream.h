/*
 *  SplitStream.h
 *  passweb
 *
 *  Created by Gabriel Lespérance on 09-03-07.
 *  Copyright 2009 Gabriel Lespérance. All rights reserved.
 *	email & info : lesperanceg@elibres.com
 */

#ifndef SPLITSTREAM

#define SPLITSTREAM

typedef struct Part{
	char * String;
	struct Part * next;
} Part, PartList;

extern int SplitStream(char *stream, size_t streamLength, char separator, PartList ** ListPtr);
extern void FreePartList(PartList * ListHead);

#endif
