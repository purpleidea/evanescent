/*
 *  CGI_Html.h
 *  submitWebsite
 *
 *  Created by Gabriel Lespérance on 09-03-26.
 *  Copyright 2009 Gabriel Lespérance. All rights reserved.
 *	email & info : lesperanceg@elibres.com
 */

#ifndef CGI_HTML
#define CGI_HTML

extern int parsePostData(char * dst, const int maxlength);
extern void printHtmlHeader(const char * pageTitle);
extern void printHtmlFooter();
#endif
