/*
 *  CGI_Html.c
 *  submitWebsite
 *
 *  Created by Gabriel Lespérance on 09-03-26.
 *  Copyright 2009 Gabriel Lespérance. All rights reserved.
 *	email & info : lesperanceg@elibres.com
 */

#include <stdio.h>
#include <stdlib.h>

#include "CGI_Html.h"



#define POST_METHOD_PADDING 5

int unencode(char * src, char * dst, const int length){
	char byteChar;
	int i,j;
	
	for(i=0, j=0 ; i<length ; i++, j++){
		
		if(*(src+i) == '+'){		//Replace all '+' by spaces
			
			*(dst+j) = ' ';
			
		}else if(*(src+i) == '%'){	//Replace all unicode "chars" by their respective char 
			
			if(sscanf((src+1), "%2x", &byteChar) !=1){
				byteChar = '?';
			}
			
			*(dst+j) = byteChar;
			i+=2;

		}else{
			*(dst+j) = *(src+i);
		}
	}
	
	*(dst+j+1) = '\0';
	
	return j;
}

int parsePostData(char * dst, const int maxlength){
	
	char * lengthStr, *input;
	int length, ret;
	
	lengthStr = getenv("CONTENT_LENGTH");

	
	if(lengthStr == NULL || sscanf(lengthStr,"%ld",&length) !=1 || length >= maxlength){
		printf("<h3>Error</h3><p>Input Error.</p>");
		return -1;
	}
	
	length++;
	
	input = malloc(length);
	fgets(input, length, stdin);
	
	ret = unencode(input, dst, (const int) length);
	free(input);
	return ret;
}

void printHtmlHeader(const char * pageTitle){
	printf("%s%c%c\n","Content-Type:text/html;charset=iso-8859-1",13,10);
	printf("<html><head><title>MP3 --- Music Portal 3 --- The best place to get your music! </title><link rel=\"stylesheet\" type=\"text/css\" href=\"../project.css\" /></head><body><div id=\"container\"><div id=\"head_logo\"></div><div id=\"header\"><!--<div class=\"rule-header\"></div>--><div id=\"section_title\"><h1>%s<h1></div><div align=\"right\"><APPLET CODE=\"Clock3D.class\" WIDTH=278 HEIGHT=50><PARAM NAME=fps VALUE=15><PARAM NAME=a1 VALUE=12500><PARAM NAME=pixangle VALUE=0><PARAM NAME=radius ALUE=20><PARAM NAME=roty VALUE=-4><PARAM NAME=style VALUE=1><PARAM NAME=color VALUE=#00FF66><PARAM NAME=bgcolor VALUE=#000000><PARAM NAME=12hour VALUE=0></APPLET></div><div id=\"main_menu\"><ul><li><a id=\"main_menu_link\" href=\"../\">Homepage</a></li><li><a id=\"main_menu_link\" href=\"../login.html\">Login</a></li><li><a id=\"main_menu_link\" href=\"../catalogue.html\">Web Catalogue</a></li></ul></div></div><div id=\"dependent\"><div id=\"content_box\"><div id=\"content\">", pageTitle);
}

void printHtmlFooter(){
	printf("<img src=\"../files/music_portal_3.jpg\" class=\"leftimg-in\" align=right></div></div></div></div></body></html>");
}
