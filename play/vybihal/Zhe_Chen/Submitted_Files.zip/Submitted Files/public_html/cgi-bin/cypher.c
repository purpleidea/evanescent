/*
 *  cypher.c
 *  passweb
 *
 *  Created by Gabriel Lespérance on 09-03-07.
 *  Copyright 2009 Gabriel Lespérance. All rights reserved.
 *  email & info : lesperanceg@elibres.com
 */

#include "cypher.h"

void CypherStream(char *Stream, size_t StreamSize,int Key){
	int i=0;
	for(i=0; i<StreamSize ; i++){
		Stream[i] = (Stream[i] + Key % 256 + 256) % 256; // but then it wouldn't be necessary since overflowing an ascii char wraps the value around 256 ie: 255+1 = 0
	}
}

void DecryptStream(char *Stream, size_t StreamSize, int Key){
	return CypherStream(Stream, StreamSize, -Key);
}
