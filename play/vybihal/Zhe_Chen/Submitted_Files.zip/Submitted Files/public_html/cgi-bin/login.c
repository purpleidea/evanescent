/*
 *  login.c
 *  submitWebsite
 *
 *  Created by Gabriel Lespérance on 09-03-26.
 *  Copyright 2009 Gabriel Lespérance. All rights reserved.
 *	email & info : lesperanceg@elibres.com
 */

#include <string.h>
#include <stdio.h>

#include "SplitStream.h"
#include "cypher.h"

#include "login.h"

//////////////////////////////
/// DEFINES / CONST INFO
/////////////////////////////

#define CYPHER_ENABLED

const int Key = 333;

const char CSVPATH[] = "./password.csv";

//////////////
// FUNCTIONS
/////////////

int OpenFile(const char * Path, const char ** FileStream){
	FILE * InputText;
	
	int FileSize;
	
	InputText = fopen(Path, "r");
	if(InputText == NULL){
		return -1;
	}
	
	fseek(InputText, 0 , SEEK_END);
	FileSize = ftell(InputText);
	rewind (InputText);
	
	*FileStream = malloc(FileSize);
	fread((char *) *FileStream, 1, FileSize, InputText);
	
	fclose(InputText);
	
	return FileSize;
}


int validate_login(const char * username, const char * password){
	char * FileStream;
	int FileSize, ret;
	
	Part * UserInfo;
	Part * CurLine;
	
	FileSize = OpenFile(CSVPATH, (const char **) &FileStream);
#ifdef CYPHER_ENABLED
	DecryptStream(FileStream, FileSize, Key);
#endif
	
	if(FileSize <= 0){
		return -1;
	}
	
	SplitStream(FileStream, FileSize, '\n', &CurLine);
	
	for(; CurLine != NULL; CurLine = CurLine->next){
		ret = SplitStream(CurLine->String, strlen(CurLine->String), ' ', &UserInfo);
		if(ret == 2 && strcmp(username,UserInfo->String) == 0 && strcmp(password, UserInfo->next->String) == 0){
			return 1;
		}
	}
	
	return 0;
}
