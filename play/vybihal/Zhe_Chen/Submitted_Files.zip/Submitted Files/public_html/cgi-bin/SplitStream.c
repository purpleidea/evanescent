/*
 *  SplitStream.c
 *  passweb
 *
 *  Created by Gabriel Lespérance on 09-03-07.
 *  Copyright 2009 Gabriel Lespérance. All rights reserved.
 *	email & info : lesperanceg@elibres.com
 */

#include <stdlib.h>
#include <string.h>

#include "SplitStream.h"

void FreePart(Part * part){
	free(part->String);
	free(part);
}

void FreePartList(PartList * ListHead){
	if(ListHead == NULL){return;}
	if(ListHead->next != NULL){
		FreePartList(ListHead->next); 
	}
	FreePart(ListHead);	
}

Part * CreatePart(Part * PrevPart){
	Part * newPart;
	
	newPart = malloc(sizeof(Part));
	
	newPart->next = NULL;
	
	if(PrevPart != NULL){
		PrevPart->next = newPart;
	}
	return newPart;
}


int SplitStream(char *stream, size_t streamLength, char separator, PartList ** ListPtr){
	int i, length, j = 0;
	PartList * List = NULL;
	Part * cur = NULL;
	
	length = 0;
	for(i=0; i<streamLength; i++, length++){
		//printf("%c", stream[i]);
		if(stream[i] == separator || i == streamLength - 1){
			
			cur = CreatePart(cur);
			
			if(List == NULL){ List = cur;}
			
			if(stream[i] != separator){
				//printf("end of string");
				cur->String = malloc(length+1);
				memcpy(cur->String, stream+i-length, length+1);
				cur->String[length+1] = '\0';
			}else{
				cur->String = malloc(length);
				memcpy(cur->String, stream+i-length, length);
				cur->String[length] = '\0';
			}
			
			j++;
			length = -1;
		}
	}
	
	*ListPtr = List;
	
	return j;
}
