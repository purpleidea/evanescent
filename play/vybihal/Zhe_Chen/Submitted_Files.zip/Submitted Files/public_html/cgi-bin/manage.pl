#!/usr/bin/perl
#------------------------------------------------------
# Comp_206_Assignment_5
#------------------------------------------------------
# Gabriel Lesp�rance 260332461 
# Rodrigo Zanini 260332743
# Zhe Chen 260256663
#------------------------------------------------------

use IO::File;
use CGI;

#variable for file name.
my $PageTitle = "System Operator Management Page";
my $file = 'inventory.csv'; 

#
# Subroutine for deleting an item
#
sub del
{
	#This variable stores the name of the item we are going to delete.
	local $name = $_[0];

	#Boolean variable to see if the item exists in the file.
	local $hasItem = 0; #Initially set it to be false.
	
	#Load file to array line by line.	
	open(FILE, "$file") || Error("Unable to open $file. $!.\n");
	@lines = <FILE>;
	close(FILE) || die("Failure to close $file. $!.\n");

	#Loop through the array to find the item we want to delete.
	for ($i = 0; $i < @lines; $i++)
	{
		#Token the line by the pattern "name, quantity, price".		
		local @components = split/ /,"$lines[$i]";

		#Compare if the names are the same	
		if ($components[0] eq $name)
		{	#If they happen to be the same, then delete it from the array.
			splice(@lines, $i, 1);
			$hasItem = 1;#Assign the boolean variable to be true.
			#print("Item deleted.\n");
			last; #break out the loop
		} 
	}
	
	#If did not find the item in the file, displaying the not found message.
	if ($hasItem == 0)
	{
		#print("Did not find the item.\n");
	}

	#write back to file.
	open(FILE, "> $file") || die("Unable to open $file. $!.\n");
	foreach $line (@lines)
	{
		print(FILE "$line");
	}
	close(FILE) || die("Failure to close $file. $!.\n");
	#print("Done!\n");
	
}

#
# Subroutine for adding an item
#
sub add
{
	#Variable declaration
	$name = $_[0];		#This variable stores the name of the item we are going to add.
	$quantity = $_[1];	#This variable stores the quantity of the item.
	$price = $_[2];		#This variable stores the price of the item.

	#Boolean variable to see if the item exists in the file.
	local $hasItem = 0; #Initially set it to be false.

	#Read from file.
	open(FILE, "$file") || die("Unable to open $file. $!.\n");
	@lines = <FILE>;
	close(FILE) || die("Failure to close $file. $!.\n");

	#Loop through the array and check if the item added exists.
	for ($i = 0; $i < @lines; $i++)
	{
		#Token the line by the pattern "name, quantity, price".	
		local @components = split/,/, "$lines[$i]";
		
		#Compare if the names are the same
		if ($components[0] eq $name)
		{	#If they happen to be the same, then replace it.
			$lines[$i] = "$name, $quantity, $price\n";
			print("Found $name in line $i and replaced\n");
			
			#write back to file if found the item.			
			open(FILE, "> $file") || die("Unable to open $file. $!.\n");
			foreach $line (@lines)
			{
				print(FILE "$line");
			}
			close(FILE) || die("Failure to close $file. $!.\n");
			print("Done!\n");
			return;

		} 
	}
	
	#Append to the end of the list.
	push(@lines, "$name, $quantity, $price\n");
	print("Appended the item at the end of list.\n");

	#write back to file.
	open(FILE, "> $file") || die("Unable to open $file. $!.\n");
	foreach $line (@lines)
	{
		print(FILE "$line");
	}
	close(FILE) || die("Failure to close $file. $!.\n");
	print("Done!\n");
}

sub error
{
	print("<h3>Error</h3><p>Input Error.</p>");
}

sub printHtmlHeader{
	my $PageName =$_[0];
	print "Content-Type: text/html\n\n";
	print "<html><head><title>MP3 --- Music Portal 3 --- The best place to get your music! </title><link rel=\"stylesheet\" type=\"text/css\" href=\"../project.css\" /></head><body><div id=\"container\"><div id=\"head_logo\"></div><div id=\"header\"><!--<div class=\"rule-header\"></div>--><div id=\"section_title\"><h1>$PageName<h1></div><div align=\"right\"><APPLET CODE=\"Clock3D.class\" WIDTH=278 HEIGHT=50><PARAM NAME=fps VALUE=15><PARAM NAME=a1 VALUE=12500><PARAM NAME=pixangle VALUE=0><PARAM NAME=radius ALUE=20><PARAM NAME=roty VALUE=-4><PARAM NAME=style VALUE=1><PARAM NAME=color VALUE=#00FF66><PARAM NAME=bgcolor VALUE=#000000><PARAM NAME=12hour VALUE=0></APPLET></div><div id=\"main_menu\"><ul><li><a id=\"main_menu_link\" href=\"../\">Homepage</a></li><li><a id=\"main_menu_link\" href=\"../login.html\">Login</a></li><li><a id=\"main_menu_link\" href=\"../catalogue.html\">Web Catalogue</a></li></ul></div></div><div id=\"dependent\"><div id=\"content_box\"><div id=\"content\">";
	print "<script language=\"javascript\">function DeleteItem\(Item\)\{document.TheForm.command.value=\"del\"; document.TheForm.ItemToDel.value=Item;document.TheForm.submit\(\);}";
	print "function AddItem\(\)\{document.TheForm.command.value=\"add\";document.TheForm.submit\(\);}";
	print "</script>";
	print "<form method=\"POST\" action=\"manage.pl\" name=\"TheForm\">";
	print "<input type=\"hidden\" name=\"command\" value=\"\">";
	print "<input type=\"hidden\" name=\"ItemToDel\" value=\"\">";
}

sub printHtmlFooter{
	print "</form><img src=\"../files/music_portal_3.jpg\" class=\"leftimg-in\" align=right></div></div></div></div></body></html>";
}

sub list{
	open(FILE, "$file") || die("<h3>Unable to open $file. $!.\n</h3>");
	@lines = <FILE>;
	close(FILE) || die("Failure to close $file. $!.\n");
	
	print "<table id=\"catalog\" border=\"1\">";
	print "<tr><td>#</td><td>Item Name</td><td>Quantity</td><td>Price</td></tr>";

	for ($i = 0; $i < @lines; $i++)
	{
		#Token the line by the pattern "name, quantity, price".		
		local @components = split/ /,"$lines[$i]";
		print "<tr><td>$i</td><td>$components[0]</td><td>$components[1]</td><td>$components[2]</td><td><input type=\"button\" value=\"Delete\" onClick=\"DeleteItem\(\'$components[0]\'\);\"</td></tr>";
	}
	print "</table>";

}

#
# Main part
#

local ($buffer, @pairs, $pair, $name, $value, %values);

# Read in text
$ENV{'REQUEST_METHOD'} =~ tr/a-z/A-Z/;
if ($ENV{'REQUEST_METHOD'} eq "POST")
{
    read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
}else {
    $buffer = $ENV{'QUERY_STRING'};
}
# Split information into name/value pairs
@pairs = split(/&/, $buffer);
foreach $pair (@pairs)
{
	($name, $value) = split(/=/, $pair);
	$value =~ tr/+/ /;
	$value =~ s/%(..)/pack("C", hex($1))/eg;
	$values{$name} = $value;
}

printHtmlHeader($PageTitle);

if($values{'command'} =~ 'add'){
	add($values{'newItemName'}, $values{'newItemQuantity'}, $values{'newItemPrice'});
}elsif($values{'command'} =~ 'del'){
	del($values{'ItemToDel'});
}

list();

print "<br>";
print "<table id=\"catalog\" border=\"1\">";
print "<tr><td>Item Name</td><td>Quantity</td><td>Price</td></tr>";
print "<tr><td><input type=\"text\" name=\"newItemName\" size=\"15\"></td><td><input type=\"text\" name=\"newItemQuantity\" size=\"4\"></td><td<input type=\"text\" name=\"newItemPrice\" size=\"6\"></td></tr>";
print "<tr><td colspan=\"3\"><input style=\"width:100%\" type=\"button\" value=\"Add Item\" onClick=\"AddItem();\"></td>";
print "</table>";
printHtmlFooter();