/*
 *  cypher.h
 *  passweb
 *
 *  Created by Gabriel Lespérance on 09-03-07.
 *  Copyright 2009 Gabriel Lespérance. All rights reserved.
 *  email & info : lesperanceg@elibres.com
 */
#include <stdlib.h>

#ifndef CYPHER
#define CYPHER
extern void DecryptStream(char *Stream, size_t StreamSize, int Key);
extern void CypherStream(char *Stream, size_t StreamSize,int Key);
#endif
