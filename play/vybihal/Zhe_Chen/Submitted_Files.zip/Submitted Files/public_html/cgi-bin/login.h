/*
 *  login.h
 *  submitWebsite
 *
 *  Created by Gabriel Lespérance on 09-03-26.
 *  Copyright 2009 Gabriel Lespérace. All rights reserved.
 *	email & info : lesperanceg@elibres.com
 */

#ifndef LOGIN
#define LOGIN

extern int validate_login(const char * username, const char * password);

#endif

