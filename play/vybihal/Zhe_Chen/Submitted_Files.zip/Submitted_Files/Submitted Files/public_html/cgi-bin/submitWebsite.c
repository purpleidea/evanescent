#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "CGI_Html.h"
#include "SplitStream.h"
#include "login.h"

//"IMPORTANT : IF YOU WANT TO COMPILE SUBMITWEBSITE.CGI YOU --- MUST --- USE THE PROVIDED MAKE FILE..."

##################################### start of comment 
THE BUY.c file has been coded into the submitWebsite.c... There's a lot of comment in it and you should have no problem to find the code for buy.c For us it made more sense to do that, that way since submitWebsite already handled the decoding of the submitter POST info. **** IMPORTANT use make to compile the submitwebsite (which replaces buy.c **** /////////////////////////////////// Also, I can confirm that the manage.pl IS WORKING since i have tested it on another system with a POSIX CGI implementation BUT due to an unknown bug, it keeps giving "500 internal error" on the www.cs.mcgill.ca server... If there's any problem with it please reach me (gabriel lesperance) thanks GLH on behalf of the team 
################## end of comment


////////////////////////
// CONSTANTS & DEFINE
///////////////////////

//#define DEBUG

#define MAX_PARAM_LENGTH 255								// These static values are all approximations since we don't know how much data we will actually get... 
#define MAX_PARAMS	7	// be careful____ Ajust theses to fit your needs									// 
#define MAX_DATA_LENGTH 2*MAX_PARAMS*MAX_PARAM_LENGTH		//note : Times 2 since names we also store parameters' names.

const char PageTitle[] = "submitWebsite.cgi - Results";

const char commandName[] = "command";

const char loginCommand[] = "login";
const char catalogueCommand[] = "catalogue";

const char usernameVar[] = "login";
const char passwordVar[] = "password";

////////////////////////////////////////////
// STATIC VARIABLES & STRUCT DECLARATION
////////////////////////////////////////////

typedef struct Param {
	char * name;
	char * value;
} Param;

//////////////////////
// GLOBAL VARIABLES
//////////////////////

Param ParamArray[MAX_PARAMS];
int ParamNum = 0;

char InputData[MAX_DATA_LENGTH+1];

//////////////
// FUNCTIONS
/////////////

int AddParam(char * name, char * value){
	
	if(ParamNum >= MAX_PARAMS){
#ifdef DEBUG
		printf("DEBUG: Reached the maximum number of params.<br>");
#endif
		return -1;
	}
	
	ParamArray[ParamNum].name = name;
	ParamArray[ParamNum].value = value;
	
#ifdef DEBUG
	printf("DEBUG: Adding Var \'%s\' : \'%s\' <br>", ParamArray[ParamNum].name, ParamArray[ParamNum].value);
#endif
	
	ParamNum++;
	
	return ParamNum;
}

Param * FindParam(const char * name){
	int i;

#ifdef DEBUG
	printf("DEBUG: Looking for \'%s\' : ", name);
#endif
	
	for(i=0; i<ParamNum; i++){
		if(strncmp(ParamArray[i].name, name, MAX_PARAM_LENGTH) == 0){
#ifdef DEBUG
			printf("Found.<br>");
#endif
			return &(ParamArray[i]);
		}
	}
	
#ifdef DEBUG
	printf("Not Found.<br>");
#endif
	return NULL;
}

int parseParams(){
	int ret;
	
	PartList *ParamList, *curParam;
	Part *curPart; 
	
	ret = parsePostData(InputData, MAX_DATA_LENGTH+1);
	if(ret <= 0){
		return ret;
	}
	
	ret = SplitStream(InputData, ret, '&', &ParamList);
	
	for(curPart = ParamList; curPart!= NULL; curPart = curPart->next){
		
		if(SplitStream(curPart->String, strlen(curPart->String), '=', &curParam) == 2){
			
			AddParam(curParam->String, curParam->next->String);
			
			free(curParam->next);
			free(curParam);
		}
	}
	FreePartList(ParamList);
	return ParamNum;	
}

void login(char * username, char * password){
	
	if(validate_login((const char *) username, (const char * ) password) == 1){
		printf("<h3>Welcome %s</h3><p>Click <a href=\"./manage.pl\">Here</a> to be redirected to the management page...</p>", username);
	}else{
		printf("<h3>Try again.</h3><p>Incorrect User/Password pair</p>");
	}
}

int catalogue(){
	FILE* fp;
    
    // open file, and check for errors
    fp = fopen("queryCatalogue.txt", "a");
	
    if (fp == NULL) {
        printf("Error! The specified file cannot be found!\n");
        return -1;
    }
	
    // add query to end of file
    fprintf(fp,"%s\n",InputData);
	
    fclose(fp);
	
	return 0;
}

int bill() {

	FILE *ifp, *ofp;
    					
    	// open file, and check for errors
	
	int i = 0;
	Param *item = NULL;
	char *result = NULL;
	char *seq = NULL;
	float total = 0;
	char *itemname = (char *)malloc(20); 
	for (i = 1; i < ParamNum;) {
		strcpy(itemname, ParamArray[i].name);	
		result = strtok(itemname, "-");
		if (result != NULL) {
			seq = strtok(NULL, "-");
    			if (!strcmp(result, "item")) { 
				char *amountname = (char *)malloc(20);
				sprintf(amountname, "amount-%s", seq);
				if (i + 1 < ParamNum && !strcmp(ParamArray[i+1].name, amountname)) {					
					int num = atoi(ParamArray[i+1].value);
					char *str = (char *)malloc(20);
					int store_num;
					float price;
					ifp = fopen("inventory.csv", "r");
					ofp = fopen("inventory.tep", "w");
	
					if (ifp == NULL) {
						printf("Error! The specified file cannot be found!\n");
						return -1;
					}

					while (fscanf(ifp, "%s %d %f", str, &store_num, &price) != EOF) {

 						if (!strcmp(str, ParamArray[i].name)) {
							if (num <= store_num) {
								printf("<p>the cost for %s is %0.2f</p>", ParamArray[i].name, num * price);
								total += num * price;
								fprintf(ofp, "%s %d %0.2f\n", str, store_num - num,price);
							}
							else {
								printf("<p>sorry we don't have enough %s in store</p>", ParamArray[i].name);
								fprintf(ofp, "%s %d %0.2f\n", str, store_num,price);
							}

							
						}
						else {
							fprintf(ofp, "%s %d %0.2f\n", str, store_num, price);
						}
					}
					fclose(ifp);
					fclose(ofp);
					remove("inventory.csv");
					rename("inventory.tep", "inventory.csv");
					free(str);
					i = i + 2;					
				}
				else {
					i++;					
				}
				free(amountname);
			}
			else {
				i++;
			}
		}
	}

	free(itemname);
	
	printf("<p>the gross total cost is %0.2f</p>", total);
	printf("<p>the total cost plus tax is %0.3f</p>", total * 1.075 * 1.05);	
	
	return 0;
}

int main (int argc, const char * argv[]) {
	Param * command, *username, *password;

    printHtmlHeader((const char *) &PageTitle);
	
	parseParams();
	
	command = FindParam(commandName);

	if(command == NULL){
		printf("<h3>Error</h3><p>Input Error.</p>");
	}else if(strncmp(command->value, loginCommand, MAX_PARAM_LENGTH) == 0){

#ifdef DEBUG
		printf("DEBUG: Calling Login function<br>");
#endif
		username = FindParam(usernameVar);
		password = FindParam(passwordVar);
		
		if(username != NULL && password != NULL){
			login(username->value,password->value);
		}else{
			printf("<h3>Error</h3><p>Input Error.</p>");
		}
		
	}else if(strncmp(command->value, catalogueCommand, MAX_PARAM_LENGTH) == 0){
		
		if(catalogue() >= 0){
			bill();
			printf("<h3>Order Completed.<h3><p>Your order has been received... Thanks!</p>");			
		}
		
	}else{
		printf("<h3>Error</h3><p>Input Error.</p>");
	}
	
	printHtmlFooter();

    return 0;
}
