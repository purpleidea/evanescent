#!/usr/bin/python
"""
    Evanescent machine idle detection and shutdown tool.
    Copyright (C) 2008  James Shubin, McGill University
    Written for McGill University by James Shubin <purpleidea@gmail.com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
DOT = '.'
DASH = '-'
LBRACKET = '['
RBRACKET = ']'
#these ips will not allow computer to shutdown
ipSafeList = ['132.206.52.237','127.0.0.1', '132.206.52.48', ]

class ip:

	def __init__(self, force_brackets=False):
		self.force_brackets = force_brackets

	def is_ipv4(self, ipv4_str):
		# assume no brackets are present until found...
		lhs_bracket = False
		rhs_bracket = False

		# default include/exclude behaviour for brackets when not specified is:
		lhs_include = True
		rhs_include = True

		if ipv4_str[0] == LBRACKET:
			lhs_bracket = True
			lhs_include = True
		if ipv4_str[0] == RBRACKET:
			lhs_bracket = True
			lhs_include = False

		if lhs_bracket:	# chop off left bracket
			ipv4_str = ipv4_str[1:]

		if ipv4_str[-1] == LBRACKET:
			rhs_bracket = True
			rhs_include = False
		if ipv4_str[-1] == RBRACKET:
			rhs_bracket = True
			rhs_include = True

		if rhs_bracket:	# chop off right bracket
			ipv4_str = ipv4_str[:-1]

		if self.force_brackets and (not(lhs_bracket) or not(rhs_bracket)):
			raise SyntaxError, 'missing left and right square brackets'
		# now split it up
		ipv4_str = ipv4_str.strip()
		split = ipv4_str.strip().split(DOT)

		if (len(split) < 4):
			raise SyntaxError, 'IP does not conform to IPv4 standards, require 4 octets'
		for i in(split):
			if(len(i) > 3):
				raise SyntaxError, 'IP is too long. each octet of IPv4 can be at most 3 digits'
			elif( int(i) > 255):
				raise SyntaxError, '255 is the maximum value of each octet'
			elif( int(i) < 0):
				raise SyntaxError, '0 is minimum value of each octet'
		if(ipv4_str in ipSafeList):
			return True
		else:
			return False


	def is_ipv6(self, ipv6_str):
		raise NotImplementedError

	
