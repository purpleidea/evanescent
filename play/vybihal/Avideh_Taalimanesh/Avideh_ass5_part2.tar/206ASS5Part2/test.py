#!/usr/bin/python

import dt

obj = dt.dt()

print 'Are we between 2009-01-01 and 2009-04-01? '

print obj.is_date('[2009-01-01,2009-04-01]')

print 'Are we between 2009-01-01 and 2009-05-01? '

print obj.is_date('[2009-01-01,2009-05-01]')

print 'Are we between Monday and Thursday? '

print obj.is_day('[0,3]')

print 'Are we between Friday and Sunday? '

print obj.is_day('[4,6]')
