# setup.py
from distutils.core import setup

#windows installer:
# python setup.py bdist_wininst

setup(
    name="win32screensaver",
    description="Python Win32 Screensaver Library",
    version="0.3.2",
    author="Chris Liechti",
    author_email="cliechti@gmx.net",
    #~ url="http:///",
    license="Python",
    #~ long_description="",
    classifiers=[
        'Intended Audience :: Developers',
        'License :: OSI Approved :: Python Software Foundation License',
        'Natural Language :: English',
        'Operating System :: Microsoft :: Windows',
        'Programming Language :: Python',
    ],
)
