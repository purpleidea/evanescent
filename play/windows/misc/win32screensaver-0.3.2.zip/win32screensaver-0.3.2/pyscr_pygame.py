"""Screensaver class, derrived from the Win32 screensaver that uses pygame
to display the graphics. This class imlements the pygame event handling and
terminates the screensaver on appropriate events.

Do not override the same methods as in the normal Win32 Screensaver class as
these are used here internaly. Instead implement these:
    - pygame_initialized
    - pygame_finalize
    - pygame_tick

They have the same names, just prefixed with "pygame_". The configure()
method keeps the same name.

An important thing is that the user screensaver module does NOT import pygame!
The library needs to be initialized in a special way so that it can take
over the window from Win32. if it was imported by the user module it may fail
to work correctly. The pygame module is passed in the function that can be
overriden by the user; use that instead. See also docs on PyGameSaver.

Special to the pygame version is that it uses the windows timer that drives
the tick() function to check for events. Thus setting the TIMEBASE constant
to short or too long has effect on the reactiveness of the screensaver.
In any case it must not be set to None as that would disable the event
handling.

(C) 2003 Chris Liechti <cliechti@gmx.net>
This is distributed under a free software license, see license.txt.
"""

import pyscr
import time, threading, traceback
from winuser import*
from wincommon import *

class PyGameSaver(pyscr.Screensaver):
    """Screensaver that uses pygame as display library.
       The pygame vresion of the screensaver works slightly different than
       the Win32 one. Implement the following methods instead of the ones
       seen in the other docu:
          - pygame_initialized(self, pygame)
          - pygame_finalize(self, pygame)
          - pygame_tick(self, pygame)
          - configure(self)
       
       To write your screensaver, you must use the suplied pygame instance
       and not import it yourself. This is beacuse pygame needs a special
       initialitation to be integrated in the Win32 code.
       """
    #------------------------------------------------------------------------
    # Attributes to be changeable by the user:
    # set up timer for tick() calls, used to poll for pygame events
    # must not be None! or the screensaver does not exit on events...
    #------------------------------------------------------------------------
    TIMEBASE = 0.25

    #------------------------------------------------------------------------
    # Methods that are overriden by the user:
    #------------------------------------------------------------------------
    def pygame_initialized(self, pygame):
        """Called after the pygame stuff is initialized."""
    
    def pygame_finalize(self, pygame):
        """Called before pygame is shut down."""
        
    def pygame_tick(self, pygame):
        """Called in each timestep."""

    def configure(self):
        """Called to open the screensaver configuration."""

    #------------------------------------------------------------------------
    # Internal methods
    #------------------------------------------------------------------------
    def initialize(self):
        """called once when the screensaver is started.
           do not override in pygame mode, use pygame_tick instead!"""
        self.refpoint = None
        
        import os
        os.environ['SDL_WINDOWID'] = str(self.hWnd)
        os.environ['SDL_VIDEODRIVER'] = 'windib'
        import pygame
        self.pygame = pygame
        self.pygame.init()
        self.window = self.pygame.display.set_mode((self.width, self.height))
        if not self.fChildPreview:
            self.pygame.mouse.set_visible(False)
        self.pygame_initialized(self.pygame)
    
    def finalize(self):
        """called when the screensaver terminates.
           do not override in pygame mode, use pygame_tick instead!"""
        #~ print "finalize"
        if self.pygame is not None:
            pygame = self.pygame
            self.pygame = None
            self.pygame_finalize(pygame)
            pygame.quit()
        
    def tick(self):
        """called when the timer tick ocours.
           do not override in pygame mode, use pygame_tick instead!"""
        if self.pygame is not None:
            quitflag = False
            #call the uses tick function:
            try:
                self.pygame_tick(self.pygame)
            except:
                traceback.print_exc()
                quitflag = True
            
            #then check the events
            #don't do any special processing when in preview mode
            for e in self.pygame.event.get():
                #events that end the screensaver:
                if self.fChildPreview:
                    if e.type == self.pygame.QUIT:
                        quitflag = True
                        break
                else:
                    if e.type in (
                        self.pygame.KEYDOWN,
                        self.pygame.KEYUP,
                        self.pygame.MOUSEBUTTONDOWN,
                        self.pygame.MOUSEBUTTONUP,
                        self.pygame.QUIT,
                    ):
                        quitflag = True
                        break
                    elif e.type == self.pygame.MOUSEMOTION:
                        #set reference point on first mouse event
                        if self.refpoint is None:
                            self.refpoint = e.pos
                        elif abs(e.pos[0] - self.refpoint[0]) > 10 or\
                             abs(e.pos[1] - self.refpoint[1]) > 10:
                            quitflag = True
            if quitflag:
                #~ self.pygame_finalize(self.pygame)
                #~ self.pygame.quit()
                #~ self.pygame = None
                self.finalize()
                PostMessage(self.hWnd, WM_CLOSE, 0, 0)

main = pyscr.main

if __name__ == '__main__':
    main()