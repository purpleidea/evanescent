Python Win32 Screensaver Library
--------------------------------
This library is intended to make it easy to write windows screensavers in
Python. Screen savers using the pyscr module can be implemented with ctypes
(a little wrapper class around a DC already exits) or win32all.
The pyscr_pygame module also gives the opportunity to write the screensaver
with pygame.

The Win32 parts are implemented using ctypes.

(C) 2003 Chris Liechti <cliechti@gmx.net>

Requirements
------------
- Python 2.3
- ctypes (this lib was developed with 6.2a)
- py2exe


Installation
------------
Extract the ZIP file in the working directory or in <Python>\Lib\site-packages
or use the installer.


Usage
-----
To write a screensaver, derive a class from pyscr.Screensaver and implement
the following methods:
    - initialized   called once on init
    - finalize      called once on exit
    - tick          called periodicaly, set with TIMEBASE
    - configure     called when the screensaver has to be configured

The TIMEBASE class attribute determines the interval for the tick() calls.
The value is a time in seconds. If set to None, it will never call the
tick() method.

The user module has to contain exactly one class derrived from
pysrc.Screensaver. It is automaticaly searched. The user module just has
to call pyscr.main() - that's all!

Implement your screensaver in an own module, see test_simple.py for an
example. Run buildScr.py. The screensaver and all it's needed to run is
placed in the 'dist' directory.

Notes:
- Test your screensaver by running your script with the command line option
  "/s". That way you don't have to create an '.scr' file each time.

- The --pygame option is required when you build screensavers based on
  pysrc_pygame. The default font is missing otherwise and the screensaver
  will not run.

Examples for buildScr.py:
buildScr.py test_simple.py:
    Build the simple Win32 example screensaver.

buildScr.py --pygame test_pygame.py
    Build the simple pygame demo screensaver. Run in pygame mode.

buildScr.py --pygame -d sail* test_pygamebitmap.py
    Build a pygame screensaver from the file test_pygamebitmap.py, add
    all files that begin with "sail" to the distribution.

Reference
---------
The "pyscr" module provides the Screensaver class:
 - Screensaver.hWnd
    This is the window handle of the drawing surface. This handle can be
    passed to other libs such as win32all.
    
 - Screensaver.dc
    This is the wrapped drawing surface using windc.

 - Screensaver.width
 - Screensaver.height
    These attributes contain the size of the drawing area.

The "pyscr_pygame" module provides the Screensaver class:
 - PyGameSaver.pygame
    The pygame module. Use this reference instead of importing it.

 - PyGameSaver.width
 - PyGameSaver.height
    These attributes contain the size of the drawing area.

The "windc" module provides some drawing methods:
 - beginDrawing()
    This one must be called before any other drawing function!
    Its enough to call it once for a largr block of drawing
    operations. When the drawing is finished endDrawing has to
    be called.
    
 - endDrawing()
    Finish drawing.
    
 - drawText((x,y), text)
 - drawLine((x1,y1), (x2,y2))
 - drawRect((x1,y1), (x2,y2))
 - fillRect((x1,y1), (x2,y2))
 - invertRect((x1,y1), (x2,y2))
 - fillEllipse((x1,y1), (x2,y2))
 - setColor(color)
 - setTextColor(color)
 - setBgColor(color)
 - setBgTransparent(transparent=False)
 - setFillColor(color)
 - setFont(fontname, size=20, bold=False, italic=False, rotation=0)
 - getSize()

Colors are 32bit integers in the format 0x00bbggrr.


Links
-----
- Python: http://www.python.org
- http://ctypes.sf.net
- http://py2exe.sf.net
