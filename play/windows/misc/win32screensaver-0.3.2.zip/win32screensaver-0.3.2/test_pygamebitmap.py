"""Sample Screensaver with pygame. This one uses pygame to draw an image on
the screen, the image is moved as it where a bouncing ball.

Don't forget to specify the --pygame and -d sail.jpg option to buildScr.py.

(C) 2003 Chris Liechti <cliechti@gmx.net>
This is distributed under a free software license, see license.txt.
"""

import pyscr_pygame
import os, sys

class MovingImageSaver(pyscr_pygame.PyGameSaver):
    #set up timer for tick() calls, use a slightly faster timing than
    #the default
    TIMEBASE = 0.1

    def pygame_initialized(self, pygame):
        self.x = self.y = 0
        self.dx = self.dy = 3
        self.bmp = pygame.image.load("sail.jpg")

    def pygame_tick(self, pygame):
        self.window.fill(0)                             #clear screen
        self.window.blit(self.bmp, (self.x, self.y))    #place bitmap
        pygame.display.flip()                           #display
        #update coordinates to do a bouncing ball animantion
        self.x += self.dx                               #update coordinates
        self.y += self.dy                               #...
        #clip cordinates, change moving direction when it hits one
        #of the borders. right and bottom border checks have to be done with
        #respect to the width/height of the bitmap
        width, height = self.bmp.get_size()
        if self.x + width >= self.width or self.x <= 0:
            self.dx = -self.dx
        if self.y + height >= self.height or self.y <= 0:
            self.dy = -self.dy

if __name__ == '__main__':
    pyscr_pygame.main()