"""Sample Screensaver with pygame. This one uses pygame to draw.
It is based on the wavey text example from Pete Shinners, found 
on pygame.org

Don't forget to specify the --pygame option to buildScr.py.

(C) 2003 Chris Liechti <cliechti@gmx.net>
This is distributed under a free software license, see license.txt.
"""

import pyscr_pygame
import os, sys, math

entry_info = 'Wavey Text Screensaver'

class TextWavey:
    """Wavey Text class from Pete Shinners"""
    def __init__(self, font, message, fontcolor, amount=10):
        self.base = font.render(message, 0, fontcolor)
        self.height = self.base.get_height()
        self.width = self.base.get_width()
        self.steps = range(0, self.width, 2)
        self.amount = amount
        self.size = self.base.get_rect().inflate(0, amount*2).size
        self.offset = 0.0
    
    def animate(self):
        s = pygame.Surface(self.size)
        height = self.size[1]
        self.offset += 0.5
        for step in self.steps:
            src = pygame.Rect(step, 0, 2, height)
            dst = src.move(0, math.cos(self.offset + step*.02)*self.amount)
            s.blit(self.base, dst, src)
        return s

class WaveyTextSaver(pyscr_pygame.PyGameSaver):
    #set up timer for tick() calls, use a slightly faster timing than the default
    TIMEBASE = 0.05

    def pygame_initialized(self, pygame_param):
        global pygame
        pygame = pygame_param   #make it global so that the class above works
        #create our fancy text renderer
        bigfont = pygame.font.Font(None, self.height/10)
        white = 255, 255, 255
        self.renderer = TextWavey(bigfont, entry_info, white, 16)
        self.x = self.y = 0
        self.dx = self.dy = min(self.width/50, 5)

    def pygame_tick(self, pygame):
        #~ pygame.time.delay(40)
        self.window.fill(0)                             #clear screen
        text = self.renderer.animate()                  #generate bitmap
        self.window.blit(text, (self.x, self.y))        #place bitmap
        pygame.display.flip()                           #display
        #update coordinates to do a bouncing ball animantion
        self.x += self.dx                               #update coordinates
        self.y += self.dy                               #...
        #clip cordinates, change moving direction when it hits one
        #of the borders. right and bottom border checks have to be done with
        #respect to the width/height of the bitmap
        if self.x + self.renderer.width >= self.width or self.x <= 0:
            self.dx = -self.dx
        if self.y + self.renderer.height >= self.height or self.y <= 0:
            self.dy = -self.dy

    #~ def pygame_finalize(self, pygame_param):
        #~ print "pygame_finalize"
        #~ del self.window
        #~ del self.renderer


if __name__ == '__main__':
    pyscr_pygame.main()