"""Sample Screensaver. This one uses some Win32 drawing functions provided
by the windc class.

(C) 2003 Chris Liechti <cliechti@gmx.net>
This is distributed under a free software license, see license.txt.
"""

import pyscr

class MySaver(pyscr.Screensaver):
    #set up timer for tick() calls
    TIMEBASE = 0.25

    def configure(self):
        #called to open the screensaver configuration
        #maybe implement here something with venster or win32all
        from ctypes import windll
        windll.user32.MessageBoxA(0,
            """Here could be the screensaver configuration.
But as it is a very simple example, it does not
need any config""",
            "Python Screensaver Configuaration", 0, 0, 0)
    
    def initialize(self):
        #called once when the screensaver is started
        self.x = 0
    
    def finalize(self):
        #called when the screensaver terminates
        pass
    
    def tick(self):
        #called when the timer tick ocours, set up with startTimer from above
        self.dc.beginDrawing()
        self.dc.setColor(0xffffffL)
        self.dc.setTextColor(0xff0000L)
        self.dc.setBgColor(0x000000L)
        self.dc.setFont("arial")
        #~ self.dc.setBgTransparent(True)
        self.dc.drawLine((0+self.x, 0), (self.x*5, 50))
        self.dc.drawText((100,100), "Me iterating.... %d" % self.x)
        w,h = self.dc.getSize()
        self.dc.drawRect((0,0), (w-1,h-1))
        self.x += 1
        self.dc.fillEllipse((50, 50), (60, 60))
        self.dc.endDrawing()

#standard 'main' detection and startof screensaver
if __name__ == '__main__':
    pyscr.main()